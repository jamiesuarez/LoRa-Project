#! /bin/sh
make clean
make $1 $2
